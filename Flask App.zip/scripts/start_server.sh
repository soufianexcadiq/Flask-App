#!/bin/bash
systemctl restart flaskapp.service