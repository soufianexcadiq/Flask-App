#!/bin/bash
systemctl stop flaskapp.service || true