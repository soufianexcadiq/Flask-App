#!/bin/bash
cd /var/www/flaskapp
pip install -r requirements.txt